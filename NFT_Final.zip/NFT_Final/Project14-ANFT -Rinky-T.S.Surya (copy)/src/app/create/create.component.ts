import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { SnackbarService } from 'ngx-snackbar';
import { AccountsService } from '../accounts-service/accounts.service';
import { AuthService } from '../auth-service/auth.service';
import { BasicService } from '../basic-service/basic.service';
import { NftService } from '../nft-service/nft.service';

declare let window: any

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  @ViewChild('createNftForm', { read: NgForm, static: true }) createNftForm: any;

  imageUrl: any = "assets/images/ImageICon.png"

  patterns = {
    namePattern: "[a-zA-Z_ -]{3,14}",
    urlPattern: "((http|https)://)(www.)?"
      + '[a-zA-Z0-9@:%._\\+~#?&//=]{2,256}\\.[a-z]'
      + '{2,6}\\b([-a-zA-Z0-9@:%._\\+~#?&//=]*)'
  }

  isValidCreateNftForm: boolean
  checkSubscription: any
  id: any
  nftimage: ''
  nftimage1: any
  name: any
  externallink: any
  description: any
  collectionname: any
  type: any
  proname: any
  levelname: any
  levelvalue1: any
  levelvalue2: any
  statsname: any
  statsvalue1: any
  statsvalue2: any
  unlockablecontent: any
  explicitcontent: any
  explicitsensitivecontent: any
  supply = 1
  blockchain: any
  freeze: any
  auctionPrice = 0
  setPrice = 0
  date = ''
  newSellerVRS: any = []


  storeNft: object = {}
  storePreNft: any = []
  storeOldNft: any = []

  coinBalance: any = {
    balance: ''
  }

  tokenAddress: any = {
    shortAddress: ''
  }

  sellerVRS: any = {
    v: '',
    r: '',
    s: ''
  }


  constructor(private basicService: BasicService, private authService: AuthService, private accountsService: AccountsService, private nftService: NftService, private snackbarService: SnackbarService, private router: Router) { }

  ngOnInit(): void {

    this.storeOldNft = JSON.parse(localStorage.getItem('createNFT') || '[]')
    this.checkSubscription = JSON.parse(localStorage.getItem('subscription') || '[]')
    console.log(this.storeOldNft)

  }

  selectFile(event: any) {
    if (!event.target.files[0] || event.target.files[0].length == 0) {
      return
    }

    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);

    reader.onload = (_event) => {
      this.imageUrl = reader.result
    }
  }


  createNft() {

    function makeid(length) {
      var result = '';
      var characters = 'abcdefghijklmnopqrstuvwxyz';
      var charactersLength = characters.length;
      for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() *
          charactersLength));
      }
      return result;
    }

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds()

    this.id = (date + '-' + makeid(5) + '-' + time);

    if (this.checkSubscription.email != null) {
      this.isValidCreateNftForm = true
      if (this.createNftForm.valid) {
        this.mintNft()
        this.storeNft = (this.createNftForm.value.id = this.id, this.createNftForm.value.nftimage = this.imageUrl, this.createNftForm.value)
        this.storePreNft = this.storeOldNft
        this.storePreNft.push(this.storeNft)
        localStorage.setItem('createNFT', JSON.stringify(this.storePreNft))
        console.log(this.storeNft)
        this.isValidCreateNftForm = false
      }
      else {
        this.snackbarService.add({
          msg: ' <strong> Fill the All Required Fields </strong> ',
          timeout: 3000,
          action: {
            text: 'Close'
          }
        })
      }
    }
    else {
      this.snackbarService.add({
        msg: ' <strong> Please Make Subscription </strong> ',
        timeout: 3000,
        action: {
          text: 'Go',
          onClick: (snack) => {

            this.router.navigate([`/`]);

          },
        }
      })
    }
  }


  async mintNft() {

    let getCurrentBlock = await window.web3.eth.getBlockNumber() + 7;

    let max = 1000, min = 500
    let incrementId = Math.floor(Math.random() * (max - min + 1)) + min;

    this.basicService.getTokenAbi().subscribe((success) => {
      console.log("🚀 ~ file: create.component.ts ~ line 114 ~ CreateComponent ~ this.basicService.getTokenAbi ~ success", success)

      this.authService.ConnectWallet('metamask').subscribe((success) => {
        console.log("🚀 ~ file: create.component.ts ~ line 118 ~ CreateComponent ~ this.authService.ConnectWallet ~ success", success)

        this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
          console.log("🚀 ~ file: create.component.ts ~ line 122 ~ CreateComponent ~ this.authService.ConnectProviderWallet ~ success", success)
          this.tokenAddress = success

          let getsignerHashSh3 = window.web3.utils.soliditySha3("0x37806dd08A6C15449b7a4118F15cdC38551750dA", 708, getCurrentBlock);

          let privatekey = '9f707e1a7ff7f2af827b9dcd284f2ea1d45fbb8a4418bc8bf4ba2c20bb362744';

          this.sellerVRS = window.web3.eth.accounts.sign(getsignerHashSh3, privatekey);
          console.log("🚀 ~ file: create.component.ts ~ line 129 ~ CreateComponent ~ this.authService.ConnectProviderWallet ~ this.sellerVRS", this.sellerVRS)

          let sellvrs = {
            v: this.sellerVRS.v,
            r: this.sellerVRS.r,
            s: this.sellerVRS.s
          }

          this.newSellerVRS.push(sellvrs)

          // localStorage.setItem('sellerVRS', JSON.stringify(this.newSellerVRS))

          this.nftService.mintNft(this.authService.walletAddress, this.authService.walletAddress, 708, getCurrentBlock, this.sellerVRS.v, this.sellerVRS.r, this.sellerVRS.s, 1, "https://www.demo.com").subscribe((mint: any) => {
            if (mint.status == true) {
              this.snackbarService.add({
                msg: ' <strong> Minted Successfully </strong> ',
                timeout: 2000,
                action: {
                  text: 'Close'
                }
              })
            }

            console.log(mint)

            if (mint.status == false) {
              this.snackbarService.add({
                msg: ' <strong> User Rejected </strong> ',
                timeout: 2000,
                action: {
                  text: 'Close'
                }
              })
            }
          })
        })
      })
    })
  }

}
