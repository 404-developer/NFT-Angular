import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AllnftComponent } from './allnft/allnft.component';
import { ArtComponent } from './art/art.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { BlogComponent } from './blog/blog.component';
import { CreateComponent } from './create/create.component';
import { DomainDetailsComponent } from './domain-details/domain-details.component';
import { DomainnamesComponent } from './domainnames/domainnames.component';
import { ExploreDetailsComponent } from './explore-details/explore-details.component';
import { ExploreComponent } from './explore/explore.component';
import { FaqComponent } from './faq/faq.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './layout/footer/footer.component';
import { HeaderComponent } from './layout/header/header.component';
import { MusicComponent } from './music/music.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { NewComponent } from './new/new.component';
import { NftbuyComponent } from './nftbuy/nftbuy.component';
import { NftsellComponent } from './nftsell/nftsell.component';



const routes: Routes = [

  { path: 'footer', component: FooterComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'faq', component: FaqComponent },
  { path: '', component: HomeComponent },
  { path: 'explore', component: ExploreComponent },
  { path: 'about', component: AboutComponent },
  { path: 'allnft', component: AllnftComponent },
  { path: 'art', component: ArtComponent },
  { path: 'blog', component: BlogComponent },
  { path: 'blog-details', component: BlogDetailsComponent },
  { path: 'create', component: CreateComponent },
  { path: 'domain-details', component: DomainDetailsComponent },
  { path: 'domainnames', component: DomainnamesComponent },
  { path: 'explore-details/:id', component: ExploreDetailsComponent },
  { path: 'music', component: MusicComponent },
  { path: 'nftsell/:id', component: NftsellComponent },
  { path: 'nftbuy/:id', component: NftbuyComponent },
  { path: 'new', component: NewComponent },
  { path: 'myprofile', component: MyprofileComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
