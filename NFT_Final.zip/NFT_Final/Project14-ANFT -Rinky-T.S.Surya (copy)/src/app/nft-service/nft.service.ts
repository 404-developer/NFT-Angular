import { Injectable } from '@angular/core';
import { SnackbarService } from 'ngx-snackbar';
import { Observable } from 'rxjs';
import { AuthService } from '../auth-service/auth.service';
import { ContractService } from '../contract-service/contract.service';

@Injectable({
  providedIn: 'root'
})
export class NftService {

  constructor(private contractService: ContractService, private authService: AuthService, private snackbarService: SnackbarService) { }

  mintNft(
    from: any,
    to: any,
    id: any,
    blockExpiry: any,
    v: any,
    r: any,
    s: any,
    supply: any,
    uri: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.NftContract().then((Contract: any) => {
        Contract.methods
          .mint(
            from,
            to,
            id,
            blockExpiry,
            v,
            r,
            s,
            supply,
            uri
          )
          .send({
            from: this.authService.walletAddress,
            value: 100000000000000,
          })
          .on('confirmation', (confirmationNumber, Mintresult) => { })
          .on('receipt', async (Mintresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Successfully Minted',
              result: Mintresult,
            }
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }


  async prepareOrderHash() {

    let salt = Math.floor(Math.random() * new Date().getTime())
    let timestamp = Math.floor(new Date().getTime() / 1000) + 90000

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {

        var order = (
          [
            [
              '0xC10B110DA613A5E420685d62844f3c4f5280f0e8',
              ["0x37806dd08A6C15449b7a4118F15cdC38551750dA", 708, 2],
              ['0x0000000000000000000000000000000000000000', 0, 0],
            ],
            1,
            10000000000000,
            40,
            salt,
            timestamp,
            1,
          ]
        )

        var Orderhash = await Contract.methods.prepareOrderHash(order).call()
        console.log(Orderhash);

        localStorage.setItem('sellerorder', JSON.stringify(order))

        // let prepareOrderHash = await Contract.methods.prepareOrderHash(order).call();
        // console.log("🚀 ~ file: nft.service.ts ~ line 90 ~ NftService ~ this.contractService.ExchangeContract ~ prepareOrderHash", prepareOrderHash)

        resolve(Orderhash)
        localStorage.setItem('prepareorderhashdetails', JSON.stringify(Orderhash))
      });

    });

  }

  setApprovalForAll(
    contractAddress: any,
    approved: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.NftContract().then((Contract: any) => {
        Contract.methods
          .setApprovalForAll(
            contractAddress,
            approved
          )
          .send({
            from: this.authService.walletAddress
          })
          .on('confirmation', (confirmationNumber, Mintresult) => { })
          .on('receipt', async (SetApprovalresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Successfully Set Approved',
              result: SetApprovalresult,
            }
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }


  async prepareBuyerFeeMessage() {

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {

        let order = JSON.parse(localStorage.getItem('sellerorder'))
        console.log("🚀 ~ file: nft.service.ts ~ line 156 ~ NftService ~ this.contractService.ExchangeContract ~ order", order)

        let prepareBuyerFeeMessage = await Contract.methods.prepareBuyerFeeMessage(order, 40, '0xC10B110DA613A5E420685d62844f3c4f5280f0e8').call()
        console.log("🚀 ~ file: nft.service.ts ~ line 156 ~ NftService ~ this.contractService.ExchangeContract ~ prepareBuyerFeeMessage", prepareBuyerFeeMessage)

        resolve(prepareBuyerFeeMessage)

      });
    });

  }


  sellNft(
    order: any,
    sellerSig: any,
    buyerfeeSig: any,
    royaltyFee: any,
    royaltyReceipt: any,
    isStore: any,
    storeParams: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.ExchangeContract().then((Contract: any) => {
        Contract.methods
          .sell(
            order,
            sellerSig,
            buyerfeeSig,
            royaltyFee,
            royaltyReceipt,
            isStore,
            storeParams
          )
          .send({
            from: this.authService.walletAddress,
            gas: 210000,
            value: 10000000000000,
          })
          .on('confirmation', (confirmationNumber, Sellresult) => { })
          .on('receipt', async (Sellresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Success',
              result: Sellresult,
            };
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }





  // async bidprepareOrderHash() {

  //   return new Promise(async (resolve, reject) => {
  //     this.contractService.ExchangeContract().then(async (Contract: any) => {

  //       let buyorder = JSON.parse(localStorage.getItem('buyorder'))

  //       let prepareOrderHash = await Contract.methods.prepareOrderHash(buyorder).call();

  //       resolve(prepareOrderHash)
  //       localStorage.setItem('bidprepareorderhashdetails', JSON.stringify(prepareOrderHash))
  //     });

  //   });

  // }

  // async bidprepareBuyerFeeMessage() {

  //   return new Promise(async (resolve, reject) => {
  //     this.contractService.ExchangeContract().then(async (Contract: any) => {


  //       var order = JSON.parse(localStorage.getItem('bidsellerorder'))

  //       let prepareBuyerFeeMessage = await Contract.methods.prepareBuyerFeeMessage(order, 40, '0xC10B110DA613A5E420685d62844f3c4f5280f0e8').call()

  //       resolve(prepareBuyerFeeMessage)

  //     });
  //   });

  // }


  buyNft(
    order: any,
    sellerSig: any,
    buyerfeeSig: any,
    royaltyFee: any,
    royaltyReceipt: any,
    isStore: any,
    storeParams: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.ExchangeContract().then((Contract: any) => {
        Contract.methods
          .buy(
            order,
            sellerSig,
            buyerfeeSig,
            royaltyFee,
            royaltyReceipt,
            isStore,
            storeParams
          )
          .send({
            from: this.authService.walletAddress,
            gas: 210000,
            // value: 100000000000000,
          })
          .on('confirmation', (confirmationNumber, Sellresult) => { })
          .on('receipt', async (Sellresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Success',
              result: Sellresult,
            };
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }


  WethApprove(
    storeAddress: any,
    buyFee: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.WethContract().then((Contract: any) => {
        Contract.methods
          .approve(
            storeAddress,
            buyFee
          )
          .send({
            from: this.authService.walletAddress,
          })
          .on('confirmation', (confirmationNumber, Sellresult) => { })
          .on('receipt', async (Sellresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Success',
              result: Sellresult,
            };
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }


  // async nftBalance() {

  //   return new Promise(async (resolve, reject) => {
  //     this.contractService.NftContract().then(async (Contract: any) => {
  //       Contract.methods.balanceOf(this.authService.walletAddress,708)

  //       // resolve(Orderhash)
  //     });
  //   });

  // }


  async sellAuctionprepareOrderHash() {

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {

        // var order = [
        //   [
        //     '0xC10B110DA613A5E420685d62844f3c4f5280f0e8',
        //     ['0x37806dd08A6C15449b7a4118F15cdC38551750dA', 708, 2],
        //     ["0x08615d29CbE0039EAc28427C4029bf61Fe3e03a5", 0, 0],
        //   ],
        //   1,
        //   10000000000000,
        //   40,
        //   salt,
        //   timestamp,
        //   3,
        // ];

        let order = JSON.parse(localStorage.getItem('buyorder'))

        var Orderhash = await Contract.methods.prepareOrderHash(order).call()
        console.log(Orderhash);

        // localStorage.setItem('sellAuctionorder',JSON.stringify(order))       

        // let prepareOrderHash = await Contract.methods.prepareOrderHash(order).call();
        // console.log("🚀 ~ file: nft.service.ts ~ line 90 ~ NftService ~ this.contractService.ExchangeContract ~ prepareOrderHash", prepareOrderHash)

        resolve(Orderhash)
        // localStorage.setItem('sellAuctionorder', JSON.stringify(Orderhash))
      });

    });

  }


  async sellAuctionBuyserFeeMessage() {

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {


        var order = JSON.parse(localStorage.getItem('buyorder'))

        let prepareBuyerFeeMessage = await Contract.methods.prepareBuyerFeeMessage(order, 40, '0xC10B110DA613A5E420685d62844f3c4f5280f0e8').call()

        resolve(prepareBuyerFeeMessage)

      });
    });

  }



  async buyAuctionprepareOrderHash() {

    let salt = Math.floor(Math.random() * new Date().getTime())
    let timestamp = Math.floor(new Date().getTime() / 1000) + 90000

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {
        var buyorder = [
          [
            this.authService.walletAddress,
            ["0x08615d29CbE0039EAc28427C4029bf61Fe3e03a5", 0, 0],
            ['0x37806dd08A6C15449b7a4118F15cdC38551750dA', 708, 2],
          ],
          1000000000000000,
          1,
          40,
          salt,
          timestamp,
          2,
        ];

        localStorage.setItem('buyorder', JSON.stringify(buyorder))


        var Orderhash = await Contract.methods.prepareOrderHash(buyorder).call()
        console.log(Orderhash);


        // let prepareOrderHash = await Contract.methods.prepareOrderHash(order).call();
        // console.log("🚀 ~ file: nft.service.ts ~ line 90 ~ NftService ~ this.contractService.ExchangeContract ~ prepareOrderHash", prepareOrderHash)

        resolve(Orderhash)
        // localStorage.setItem('sellAuctionorder', JSON.stringify(Orderhash))
      });

    });

  }

  async buyAuctionBuyserFeeMessage() {

    return new Promise(async (resolve, reject) => {
      this.contractService.ExchangeContract().then(async (Contract: any) => {


        var order = JSON.parse(localStorage.getItem('buyorder'))

        let prepareBuyerFeeMessage = await Contract.methods.prepareBuyerFeeMessage(order, 40, this.authService.walletAddress).call()

        resolve(prepareBuyerFeeMessage)

      });
    });

  }


  bidNft(
    order: any,
    sellerSigVRS: any,
    buyerSigVRS: any,
    getFeeVRS: any,
    buyerAddress: any,
    buyAmount: any,
    royaltyFee: any,
    ownerAddress: any,
    isStore: any,
    params: any
  ) {
    return new Observable((subscriber) => {
      this.contractService.ExchangeContract().then((Contract: any) => {
        Contract.methods
          .bid(
            order,
            sellerSigVRS,
            buyerSigVRS,
            getFeeVRS,
            buyerAddress,
            buyAmount,
            royaltyFee,
            ownerAddress,
            isStore,
            params
          )
          .send({
            from: this.authService.walletAddress,
            gas: 210000,
            value: 1000000000000000,
          })
          .on('confirmation', (confirmationNumber, Sellresult) => { })
          .on('receipt', async (Bidresult) => {
            const sucMsg = {
              status: true,
              step: 2,
              message: 'Success',
              result: Bidresult,
            };
            subscriber.next(sucMsg);
            this.stopSubscribe(subscriber);
          })
          .on('error', async (error) => {
            const sucMsg = {
              status: false,
              message: 'error',
            };
            subscriber.next(sucMsg);
            // this.subscribeService.isWeb3Error.emit(true);
            this.stopSubscribe(subscriber);
          });
      });
    });
  }

  stopSubscribe(subscriber: any) {
    if (subscriber) {
      subscriber.unsubscribe();
    }
  }
}