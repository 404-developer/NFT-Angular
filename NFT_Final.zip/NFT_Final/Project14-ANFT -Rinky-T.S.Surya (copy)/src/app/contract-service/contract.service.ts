import { Injectable } from '@angular/core';
import { BasicService } from '../basic-service/basic.service';

declare let window:any

@Injectable({
  providedIn: 'root'
})
export class ContractService {
  methods: any;

  constructor(private basicService: BasicService) {}

  isWeb3() {
    if (window.web3 && window.web3.eth) {
      return true;
    } else {
      return false;
    }
  }

  public async TokenContract(Address) {
    if (this.isWeb3()) {
      return new Promise(async (resolve, reject) => {
        let Contract = await new window.web3.eth.Contract(
          this.basicService.TokenABI,
          Address
        );
        resolve(Contract);
      });
    }
  }

  public async NftContract() {
    if (this.isWeb3()) {
      return new Promise(async (resolve, reject) => {
        let Contract = await new window.web3.eth.Contract(
          this.basicService.RouterABI,
          this.basicService.ContractDetails.RouterContract
        );
        resolve(Contract);
      });
    }
  }

  public async ExchangeContract() {
    if (this.isWeb3()) {
      return new Promise(async (resolve, reject) => {
        let Contract = await new window.web3.eth.Contract(
          this.basicService.ExchangeABI,
          this.basicService.ContractDetails.ExchangeContract
        );
        resolve(Contract);
      });
    }
  }

  public async WethContract() {
    if (this.isWeb3()) {
      return new Promise(async (resolve, reject) => {
        let Contract = await new window.web3.eth.Contract(
          this.basicService.WethABI,
          this.basicService.ContractDetails.WethContract
        );
        resolve(Contract);
      });
    }
  }

 
}