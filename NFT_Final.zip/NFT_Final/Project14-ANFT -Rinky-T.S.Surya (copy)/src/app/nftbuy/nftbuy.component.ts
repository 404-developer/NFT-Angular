import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SnackbarService } from 'ngx-snackbar';
import { AuthService } from '../auth-service/auth.service';
import { BasicService } from '../basic-service/basic.service';
import { NftService } from '../nft-service/nft.service';

declare let window: any

@Component({
  selector: 'app-nftbuy',
  templateUrl: './nftbuy.component.html',
  styleUrls: ['./nftbuy.component.css']
})
export class NftbuyComponent implements OnInit {

  id: any
  fetchNft: any
  createNFT: any
  sellNFT: any
  checkSubscription: any

  tokenAddress: any = {
    shortAddress: ''
  }

  constructor(private _Activatedroute: ActivatedRoute, private basicService: BasicService, private authService: AuthService, private nftService: NftService, private snackbarService: SnackbarService, private router: Router) { }

  ngOnInit(): void {

    this.createNFT = JSON.parse(localStorage.getItem('createNFT'));
    this.id = this._Activatedroute.snapshot.params['id'];
    let allNfts = this.createNFT
    this.fetchNft = allNfts.find((nft: any) => nft.id == this.id);
    console.log("🚀 ~ file: nftsell.component.ts ~ line 59 ~ NftsellComponent ~ ngOnInit ~ this.fetchNft", this.fetchNft)

    this.sellNFT = JSON.parse(localStorage.getItem('createNFT') || '[]')

    this.checkSubscription = JSON.parse(localStorage.getItem('subscription') || '[]')

  }


  async buyNft() {

    if(this.checkSubscription.email != null)
    {
    this.basicService.getTokenAbi().subscribe((success) => {
      console.log("🚀 ~ file: nftbuy.component.ts ~ line 43 ~ NftbuyComponent ~ this.basicService.getTokenAbi ~ success", success)

      this.authService.ConnectWallet('metamask').subscribe((success) => {
        console.log("🚀 ~ file: nftbuy.component.ts ~ line 46 ~ NftbuyComponent ~ this.authService.ConnectWallet ~ success", success)

        this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
          console.log("🚀 ~ file: nftbuy.component.ts ~ line 49 ~ NftbuyComponent ~ this.authService.ConnectProviderWallet ~ success", success)
          this.tokenAddress = success

          this.nftService.prepareBuyerFeeMessage().then(async (suc: any) => {
            console.log(suc);


            let buyerFeeSignerprivateKey =
              '9f707e1a7ff7f2af827b9dcd284f2ea1d45fbb8a4418bc8bf4ba2c20bb362744';
            let getVRS = await window.web3.eth.accounts.sign(
              suc,
              buyerFeeSignerprivateKey
            );
            console.log(getVRS);


            var expiry = await window.web3.eth.getBlockNumber();
            expiry = Number(expiry) + Number(25);

            var inc_id = Number(708);
            let getsignerHashSh3 = await window.web3.utils.soliditySha3(
              "0x37806dd08A6C15449b7a4118F15cdC38551750dA",
              inc_id,
              expiry
            );

            let StorePrivatekey =
              '9f707e1a7ff7f2af827b9dcd284f2ea1d45fbb8a4418bc8bf4ba2c20bb362744';
            let signerSignVRS = await window.web3.eth.accounts.sign(
              getsignerHashSh3,
              StorePrivatekey
            );

            let hexToDec = parseInt(signerSignVRS.v, 16);
            console.log("🚀 ~ file: nftbuy.component.ts ~ line 86 ~ NftbuyComponent ~ this.authService.ConnectProviderWallet ~ hexToDec", hexToDec)
            let storeParams = [
              expiry,
              Number(hexToDec),
              signerSignVRS.r,
              signerSignVRS.s,
              "https://www.demo.com",
            ];

            console.log("🚀 ~ file: nftbuy.component.ts ~ line 93 ~ NftbuyComponent ~ this.authService.ConnectProviderWallet ~ storeParams", storeParams)

            let order = JSON.parse(localStorage.getItem('sellerorder'))
            console.log("🚀 ~ file: nftbuy.component.ts ~ line 95 ~ NftbuyComponent ~ this.authService.ConnectProviderWallet ~ order", order)

            let sellerSigVRS = JSON.parse(localStorage.getItem('sellervrs'))
            console.log("🚀 ~ file: nftbuy.component.ts ~ line 107 ~ NftbuyComponent ~ this.authService.ConnectProviderWallet ~ sellerSigVRS", sellerSigVRS)

            console.log(sellerSigVRS);

            this.nftService.sellNft(
              order,
              sellerSigVRS,
              getVRS,
              40,
              '0xC10B110DA613A5E420685d62844f3c4f5280f0e8',
              false,
              storeParams
            ).subscribe((suc: any) => {

              if (suc.status == true) {
                this.snackbarService.add({
                  msg: ' <strong> Buy Success </strong> ',
                  timeout: 2500,
                  action: {
                    text: 'Close'
                  }
                })
              }

              console.log(suc)

              if (suc.status == false) {
                 this.snackbarService.add({
                  msg: ' <strong> User Rejected </strong> ',
                  timeout: 2500,
                  action: {
                    text: 'Close'
                  }
                })
              }

            })
          })
        })
      })
    })
  }
  else {
    this.snackbarService.add({
      msg: ' <strong> Please Make Subscription </strong> ',
      timeout: 3000,
      action: {
        text: 'Go',
        onClick: (snack) => {
  
          this.router.navigate([`/`]);
  
        },
      }
    })
  }
}


}
