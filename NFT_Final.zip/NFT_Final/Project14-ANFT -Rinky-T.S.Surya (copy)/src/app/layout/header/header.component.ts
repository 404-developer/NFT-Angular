import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SnackbarService } from 'ngx-snackbar';
import { AccountsService } from 'src/app/accounts-service/accounts.service';
import { AuthService } from 'src/app/auth-service/auth.service';
import { BasicService } from 'src/app/basic-service/basic.service';

declare let window: any

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  coinBalance: any = {
    balance: ''
  }

  tokenAddress: any = {
    shortAddress: ''
  }

  shortAddress: any
  balance: any

  navbarCollapsed = true;
  toggleNavbarCollapsing() { this.navbarCollapsed = !this.navbarCollapsed; }

  modalRef: BsModalRef;

  constructor(private modalService: BsModalService, private authService: AuthService, private basicService: BasicService, private accountsService: AccountsService, private authSerive: AuthService, private snackbarService: SnackbarService) { }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
    this.modalRef.setClass('modal-dialog-centered');
  }

  ngOnInit(): void {

    this.shortAddress = localStorage.getItem('shortAddress');
    this.balance = localStorage.getItem('coinBalance');

    this.basicService.getTokenAbi().subscribe((success) => {
      console.log("🚀 ~ file: header.component.ts ~ line 38 ~ HeaderComponent ~ this.basicService.getTokenAbi ~ success", success)

      this.authService.ConnectWallet('metamask').subscribe((success) => {
        console.log("🚀 ~ file: header.component.ts ~ line 47 ~ HeaderComponent ~ this.authService.ConnectWallet ~ success", success)

        this.authService.ConnectProviderWallet('metamask').subscribe((success) => {
          console.log("🚀 ~ file: header.component.ts ~ line 50 ~ HeaderComponent ~ this.authService.ConnectProviderWallet ~ success", success);
          this.tokenAddress = success

          this.accountsService.getCoinBalance().subscribe((suc: any) => {
            this.coinBalance = suc
            console.log("🚀 ~ file: header.component.ts ~ line 49 ~ HeaderComponent ~ this.accountsService.getCoinBalance ~ this.coinBalance", this.coinBalance)

            localStorage.setItem('shortAddress', this.tokenAddress.shortAddress)
            localStorage.setItem('coinBalance', this.coinBalance.balance)

          })
        })
      })
    })
  }

  connectWallet() {
    window.ethereum.enable();

    window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: '0x4' }],
    })

  }

  copyMessage() {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = this.authSerive.walletAddress;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.snackbarService.add({
      msg: ' <strong> Copied </strong> ',
      timeout: 2000,
      action: {
        text: 'Close'
      }
    })
  }

}


