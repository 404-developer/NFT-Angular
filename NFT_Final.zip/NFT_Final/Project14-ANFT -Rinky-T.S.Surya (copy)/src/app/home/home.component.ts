import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SnackbarService } from 'ngx-snackbar';
import { Subscription, interval } from 'rxjs';
import { AuthService } from '../auth-service/auth.service';

declare let window: any

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  @ViewChild('emailA', { read: NgModel, static: true }) emailA: any;
  @ViewChild('emailB', { read: NgModel, static: true }) emailB: any;
  @ViewChild('emailC', { read: NgModel, static: true }) emailC: any;

  navbarCollapsed = true;
  toggleNavbarCollapsing() { this.navbarCollapsed = !this.navbarCollapsed; }

  modalRef: BsModalRef

  paymentHandler: any = null

  RisuSubscription: any
  checkSubscription: any

  constructor(private modalService: BsModalService, private snackbarService: SnackbarService, private authSerive: AuthService) { }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
    this.modalRef.setClass('modal-dialog-centered');
  }

  emailPattern = '[a-z0-9]+@[a-z]+\.[a-z]{2,3}'

  private subscription: Subscription
  isValidSubscriptionA: boolean
  isValidSubscriptionB: boolean
  isValidSubscriptionC: boolean

  public dateNow = new Date();
  public dDay = new Date('2022-05-20T11:00')
  milliSecondsInASecond = 1000;
  hoursInADay = 24;
  minutesInAnHour = 60;
  SecondsInAMinute = 60;

  timeDifference: any;
  secondsToDday: any;
  minutesToDday: any;
  hoursToDday: any;
  daysToDday: any;
  sellNft: any


  ngOnInit(): void {

    this.invokeStripe();

    this.sellNft = JSON.parse(localStorage.getItem('createNFT') || '[]')
    this.checkSubscription = JSON.parse(localStorage.getItem('subscription') || '[]')

    this.allocateTimeUnits(this.dDay)
    this.subscription = interval(1000)
      .subscribe(suc => { this.getTimeDifference(); })

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getTimeDifference() {
    this.timeDifference = this.dDay.getTime() - new Date().getTime();
    this.allocateTimeUnits(this.timeDifference);
  }

  allocateTimeUnits(timeDifference: any) {
    this.secondsToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond) % this.SecondsInAMinute);
    this.minutesToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour) % this.SecondsInAMinute);
    this.hoursToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute) % this.hoursInADay);
    this.daysToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute * this.hoursInADay));
  }

  initializePaymentA(amount: number) {
    const paymentHandler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_sLUqHXtqXOkwSdPosC8ZikQ800snMatYMb',
      locale: 'auto',
      token: function (stripeToken: any) {
        console.log({ stripeToken })

        this.RisuSubscription =
        {
          client_ip: stripeToken.client_ip,
          email: stripeToken.email,
          plan: amount
        }
        localStorage.setItem('subscription', JSON.stringify(this.RisuSubscription))
      }
    })

    this.isValidSubscriptionA = false

    if (this.emailA == null) {
      this.isValidSubscriptionA = true

      this.snackbarService.add({
        msg: ' <strong> Email Must be Required </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else if (this.checkSubscription.email == this.emailA) {
      this.snackbarService.add({
        msg: ' <strong> Already Subscribed </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else {
      if (this.emailA.length > 12)
        paymentHandler.open({
          name: 'Risu',
          description: 'Risu Subscription',
          amount: amount * 100
        })
    }
  }

  initializePaymentB(amount: number) {
    const paymentHandler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_sLUqHXtqXOkwSdPosC8ZikQ800snMatYMb',
      locale: 'auto',
      token: function (stripeToken: any) {
        console.log({ stripeToken })

        this.RisuSubscription =
        {
          client_ip: stripeToken.client_ip,
          email: stripeToken.email,
          plan: amount
        }
        localStorage.setItem('subscription', JSON.stringify(this.RisuSubscription))
      }
    })

    this.isValidSubscriptionB = false

    if (this.emailB == null) {
      this.isValidSubscriptionB = true

      this.snackbarService.add({
        msg: ' <strong> Email Must be Required </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else if (this.checkSubscription.email == this.emailB) {
      this.snackbarService.add({
        msg: ' <strong> Already Subscribed </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else {
      if (this.emailB.length > 12)
        paymentHandler.open({
          name: 'Risu',
          description: 'Risu Subscription',
          amount: amount * 100
        })
    }


  }

  initializePaymentC(amount: number) {
    const paymentHandler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_sLUqHXtqXOkwSdPosC8ZikQ800snMatYMb',
      locale: 'auto',
      token: function (stripeToken: any) {
        console.log({ stripeToken })

        this.RisuSubscription =
        {
          client_ip: stripeToken.client_ip,
          email: stripeToken.email,
          plan: amount
        }
        localStorage.setItem('subscription', JSON.stringify(this.RisuSubscription))
      }
    })


    this.isValidSubscriptionC = false

    if (this.emailC == null) {
      this.isValidSubscriptionC = true
      this.snackbarService.add({
        msg: ' <strong> Email Must be Required </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else if (this.checkSubscription.email == this.emailC) {
      this.snackbarService.add({
        msg: ' <strong> Already Subscribed </strong> ',
        timeout: 3000,
        action: {
          text: 'Close'
        }
      })
    }
    else {
      if (this.emailC.length > 10)
        paymentHandler.open({
          name: 'Risu',
          description: 'Risu Subscription',
          amount: amount * 100
        })
    }

  }


  invokeStripe() {
    if (!window.document.getElementById('stripe-script')) {
      const script = window.document.createElement("script");
      script.id = "stripe-script";
      script.type = "text/javascript";
      script.src = "https://checkout.stripe.com/checkout.js";
      script.onload = () => {
        this.paymentHandler = (<any>window).StripeCheckout.configure({
          key: 'pk_test_sLUqHXtqXOkwSdPosC8ZikQ800snMatYMb',
          locale: 'auto',
          token: function (stripeToken: any) {
            this.snackbarService.add({
              msg: ' <strong> Subscription Added Succesfully </strong> ',
              timeout: 3000,
              action: {
                text: 'Close'
              }
            })
            console.log(stripeToken)
          }
        });
      }
      window.document.body.appendChild(script);
    }
  }

}