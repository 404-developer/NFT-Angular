import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SnackbarService } from 'ngx-snackbar';
import { Subscription, interval } from 'rxjs';
import { AuthService } from '../auth-service/auth.service';
import { BasicService } from '../basic-service/basic.service';
import { NftService } from '../nft-service/nft.service';

declare let window: any

@Component({
  selector: 'app-explore-details',
  templateUrl: './explore-details.component.html',
  styleUrls: ['./explore-details.component.css']
})
export class ExploreDetailsComponent implements OnInit {

  exploreDetails: any
  id: any
  fetchNft: any
  createNFT: any

  private subscription: Subscription;

  public dateNow = new Date();
  public dDay = new Date('2022-05-20T11:00')
  milliSecondsInASecond = 1000;
  hoursInADay = 24;
  minutesInAnHour = 60;
  SecondsInAMinute = 60;

  timeDifference: any;
  secondsToDday: any;
  minutesToDday: any;
  hoursToDday: any;
  daysToDday: any;
  sellNft: any
  checkSubscription: any

  tokenAddress: any = {
    shortAddress: ''
  }

  constructor(private _Activatedroute: ActivatedRoute, private authService: AuthService, private nftService: NftService, private basicService: BasicService, private snackbarService: SnackbarService, private router: Router) { }

  ngOnInit(): void {

    this.createNFT = JSON.parse(localStorage.getItem('createNFT'));
    this.id = this._Activatedroute.snapshot.params['id'];
    let allNfts = this.createNFT
    this.fetchNft = allNfts.find((nft: any) => nft.id == this.id);
    console.log("🚀 ~ file: nftsell.component.ts ~ line 59 ~ NftsellComponent ~ ngOnInit ~ this.fetchNft", this.fetchNft)

    this.exploreDetails = JSON.parse(localStorage.getItem('createNFT') || '[]')

    this.dDay = new Date(this.fetchNft.date)

    this.allocateTimeUnits(this.dDay)
    this.subscription = interval(1000)
      .subscribe(suc => { this.getTimeDifference(); });

    this.checkSubscription = JSON.parse(localStorage.getItem('subscription') || '[]')

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getTimeDifference() {
    this.timeDifference = this.dDay.getTime() - new Date().getTime();
    this.allocateTimeUnits(this.timeDifference);
  }

  allocateTimeUnits(timeDifference: any) {
    this.secondsToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond) % this.SecondsInAMinute);
    this.minutesToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour) % this.SecondsInAMinute);
    this.hoursToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute) % this.hoursInADay);
    this.daysToDday = Math.floor((timeDifference) / (this.milliSecondsInASecond * this.minutesInAnHour * this.SecondsInAMinute * this.hoursInADay));
  }

  bidBuyNft() {

    if (this.checkSubscription.email != null) {
      this.basicService.getTokenAbi().subscribe((success) => {
        console.log("🚀 ~ file: nftsell.component.ts ~ line 127 ~ NftsellComponent ~ this.basicService.getTokenAbi ~ success", success)

        this.authService.ConnectWallet('metamask').subscribe((success) => {
          console.log("🚀 ~ file: nftsell.component.ts ~ line 132 ~ NftsellComponent ~ this.authService.ConnectWallet ~ success", success)

          this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
            console.log("🚀 ~ file: nftsell.component.ts ~ line 137 ~ NftsellComponent ~ this.authService.ConnectProviderWallet ~ success", success)
            this.tokenAddress = success

            let salt = Math.floor(Math.random() * new Date().getTime())
            let ExpiryDateFromBuyer = Math.floor(new Date().getTime() / 1000) + 90000

            var buyorder = [
              [
                this.authService.walletAddress,
                ["0x08615d29CbE0039EAc28427C4029bf61Fe3e03a5", 0, 0],
                ['0x37806dd08A6C15449b7a4118F15cdC38551750dA', 708, 2],
              ],
              1000000000000000,
              1,
              40,
              salt,
              ExpiryDateFromBuyer,
              2,
            ];

            localStorage.setItem('buyorder', JSON.stringify(buyorder))

            this.nftService.WethApprove('0x08615d29CbE0039EAc28427C4029bf61Fe3e03a5', 1000000000000000).subscribe((suc: any) => {

              if (suc.status == true) {
                this.snackbarService.add({
                  msg: ' <strong> Successfully Approved </strong> ',
                  timeout: 1000,
                  action: {
                    text: 'Close'
                  }
                })
              }
              else if (suc.status == false) {
                this.snackbarService.add({
                  msg: ' <strong> User Rejected </strong> ',
                  timeout: 1000,
                  action: {
                    text: 'Close'
                  }
                })
              }

              console.log("🚀 ~ file: explore-details.component.ts ~ line 95 ~ ExploreDetailsComponent ~ suc", suc)

              this.nftService.buyAuctionprepareOrderHash().then(async (suc: any) => {
                console.log("🚀 ~ file: explore-details.component.ts ~ line 102 ~ ExploreDetailsComponent ~ suc", suc)

                let sellSign = await window.web3.eth.personal.sign(suc, this.authService.walletAddress, '');

                let r = sellSign.slice(0, 66);
                let s = '0x' + sellSign.slice(66, 130);
                let v = '0x' + sellSign.slice(130, 132);

                let buysellervrs = { v: v, r: r, s: s, message: suc };

                if (suc.status == true) {
                  this.snackbarService.add({
                    msg: ' <strong> Bid Success </strong> ',
                    timeout: 1000,
                    action: {
                      text: 'Close'
                    }
                  })
                }
                else if (suc.status == false) {
                  this.snackbarService.add({
                    msg: ' <strong> User Rejected </strong> ',
                    timeout: 1000,
                    action: {
                      text: 'Close'
                    }
                  })
                }

                localStorage.setItem('buysellervrs', JSON.stringify(buysellervrs))


              })
            })
          })
        })
      })
    }
    else {
      this.snackbarService.add({
        msg: ' <strong> Please Make Subscription </strong> ',
        timeout: 3000,
        action: {
          text: 'Go',
          onClick: (snack) => {

            this.router.navigate([`/`]);

          },
        }
      })
    }

  }


  BidConfirm() {

    if (this.checkSubscription.email != null) {
      this.basicService.getTokenAbi().subscribe((success) => {
        console.log("🚀 ~ file: nftsell.component.ts ~ line 127 ~ NftsellComponent ~ this.basicService.getTokenAbi ~ success", success)

        this.authService.ConnectWallet('metamask').subscribe((success) => {
          console.log("🚀 ~ file: nftsell.component.ts ~ line 132 ~ NftsellComponent ~ this.authService.ConnectWallet ~ success", success)

          this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
            console.log("🚀 ~ file: nftsell.component.ts ~ line 137 ~ NftsellComponent ~ this.authService.ConnectProviderWallet ~ success", success)
            this.tokenAddress = success

            this.nftService.sellAuctionprepareOrderHash().then(async (suc: any) => {


              let sellSign = await window.web3.eth.personal.sign(suc, this.authService.walletAddress, '');

              let r = sellSign.slice(0, 66);
              let s = '0x' + sellSign.slice(66, 130);
              let v = '0x' + sellSign.slice(130, 132);

              let sellersignvrs = { v: v, r: r, s: s, message: suc };
              console.log("🚀 ~ file: explore-details.component.ts ~ line 122 ~ ExploreDetailsComponent ~ suc", suc)
              this.nftService.sellAuctionBuyserFeeMessage().then(async (message: any) => {


                let buyerFeeSignerprivateKey = '962253277896567b7a9c4d3e16d9cba7a558a7606dff7cf4b15d8554ff7c8955';

                let getFeeVRS = await window.web3.eth.accounts.sign(
                  message,
                  buyerFeeSignerprivateKey
                );

                var expiry = await window.web3.eth.getBlockNumber();
                expiry = Number(expiry) + Number(10);
                var inc_id = 708;

                let getsignerHashSh3 = await window.web3.utils.soliditySha3(
                  "0x37806dd08A6C15449b7a4118F15cdC38551750dA",
                  inc_id,
                  expiry
                );

                let StorePrivatekey =
                  '962253277896567b7a9c4d3e16d9cba7a558a7606dff7cf4b15d8554ff7c8955';
                let signerSignVRS = await window.web3.eth.accounts.sign(
                  getsignerHashSh3,
                  StorePrivatekey
                );

                let hexToDec = parseInt(signerSignVRS.v, 16);
                let params = [
                  expiry,
                  Number(hexToDec),
                  signerSignVRS.r,
                  signerSignVRS.s,
                  'https://www.demo.jpg'
                ];

                // let sellerSigVRS = JSON.parse(localStorage.getItem('sellAuctionSignvrs'))

                let buysellervrs = JSON.parse(localStorage.getItem('buysellervrs'))

                let order = JSON.parse(localStorage.getItem('buyorder'))

                this.nftService.bidNft(order, sellersignvrs, buysellervrs, getFeeVRS, this.authService.walletAddress, 10000000000000, 40, '0xC10B110DA613A5E420685d62844f3c4f5280f0e8', false, params).subscribe((suc: any) => {

                  console.log("🚀 ~ file: explore-details.component.ts ~ line 161 ~ ExploreDetailsComponent ~ suc", suc)
                })
              })
            })
          })
        })
      })
    }
    else {
      this.snackbarService.add({
        msg: ' <strong> Please Make Subscription </strong> ',
        timeout: 3000,
        action: {
          text: 'Go',
          onClick: (snack) => {

            this.router.navigate([`/`]);

          },
        }
      })
    }
  }

}
