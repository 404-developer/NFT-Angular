import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllnftComponent } from './allnft.component';

describe('AllnftComponent', () => {
  let component: AllnftComponent;
  let fixture: ComponentFixture<AllnftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllnftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllnftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
