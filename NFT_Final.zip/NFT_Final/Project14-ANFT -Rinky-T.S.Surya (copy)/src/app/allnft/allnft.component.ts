
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allnft',
  templateUrl: './allnft.component.html',
  styleUrls: ['./allnft.component.css']
})
export class AllnftComponent implements OnInit {

 

  constructor() { }

  ngOnInit() {
   
  }


  



}
