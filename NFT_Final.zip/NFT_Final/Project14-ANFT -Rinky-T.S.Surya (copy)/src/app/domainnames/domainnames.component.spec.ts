import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DomainnamesComponent } from './domainnames.component';

describe('DomainnamesComponent', () => {
  let component: DomainnamesComponent;
  let fixture: ComponentFixture<DomainnamesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DomainnamesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DomainnamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
