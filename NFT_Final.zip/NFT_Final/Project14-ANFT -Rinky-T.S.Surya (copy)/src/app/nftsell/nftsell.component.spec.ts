import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NftsellComponent } from './nftsell.component';

describe('NftsellComponent', () => {
  let component: NftsellComponent;
  let fixture: ComponentFixture<NftsellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NftsellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NftsellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
