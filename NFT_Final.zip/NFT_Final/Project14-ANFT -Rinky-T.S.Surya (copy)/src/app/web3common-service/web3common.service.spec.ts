import { TestBed } from '@angular/core/testing';

import { Web3commonService } from './web3common.service';

describe('Web3commonService', () => {
  let service: Web3commonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Web3commonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
