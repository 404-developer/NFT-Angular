import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domain-details',
  templateUrl: './domain-details.component.html',
  styleUrls: ['./domain-details.component.css']
})
export class DomainDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
