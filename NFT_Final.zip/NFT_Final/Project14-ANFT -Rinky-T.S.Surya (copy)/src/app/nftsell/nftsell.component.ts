import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SnackbarService } from 'ngx-snackbar';
import { AccountsService } from '../accounts-service/accounts.service';
import { AuthService } from '../auth-service/auth.service';
import { BasicService } from '../basic-service/basic.service';
import { NftService } from '../nft-service/nft.service';

declare let window: any

@Component({
  selector: 'app-nftsell',
  templateUrl: './nftsell.component.html',
  styleUrls: ['./nftsell.component.css']
})
export class NftsellComponent implements OnInit {

  @ViewChild('sellNftForm', { read: NgForm, static: true }) sellNftForm: any;
  @ViewChild('setPrice', { read: NgModel, static: true }) setPrice: any;

  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  minDate = new Date();
  isValidSellNftForm: any

  isValidsellNftForm: boolean

  nftName: any
  checkSubscription: any
  id: any
  fetchNft: any
  auctionPrice: any
  date: any
  createNFT: any
  BuyerFeeMessage: any
  sellerV: any
  sellerR: any
  sellerS: any
  sellNFT: any
  fetchNftID: any
  storeNft: object = {}
  storePreNft: any = []
  storeOldNft: any = []

  tokenAddress: any = {
    shortAddress: ''
  }

  storeSellNft: object = {}
  storePreSellNft: any = []
  storeSellOldNft: any = []

  getvrsDetails: any = {
    v: '',
    r: '',
    s: ''
  }

  constructor(private _Activatedroute: ActivatedRoute, private router: Router,
    private basicService: BasicService, private authService: AuthService, private accountsService: AccountsService, private nftService: NftService, private snackbarService: SnackbarService) {
    this.minDate.setDate(this.minDate.getDate() - 1);
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }

  ngOnInit(): void {

    this.createNFT = JSON.parse(localStorage.getItem('createNFT'));
    this.id = this._Activatedroute.snapshot.params['id'];
    let allNfts = this.createNFT
    this.fetchNft = allNfts.find((nft: any) => nft.id == this.id);
    console.log("🚀 ~ file: nftsell.component.ts ~ line 59 ~ NftsellComponent ~ ngOnInit ~ this.fetchNft", this.fetchNft)

    this.sellNFT = JSON.parse(localStorage.getItem('createNFT') || '[]')

    // let sellerVRS = JSON.parse(localStorage.getItem('sellerVRS'))
    // this.sellerV = sellerVRS[0].v
    // this.sellerR = sellerVRS[0].r
    // this.sellerS = sellerVRS[0].s

    this.checkSubscription = JSON.parse(localStorage.getItem('subscription') || '[]')

  }

  sellNft() {


    if (this.checkSubscription.email != null) {

      this.isValidsellNftForm = true

      if (this.setPrice)

        this.basicService.getTokenAbi().subscribe((success) => {
          console.log("🚀 ~ file: nftsell.component.ts ~ line 127 ~ NftsellComponent ~ this.basicService.getTokenAbi ~ success", success)

          this.authService.ConnectWallet('metamask').subscribe((success) => {
            console.log("🚀 ~ file: nftsell.component.ts ~ line 132 ~ NftsellComponent ~ this.authService.ConnectWallet ~ success", success)

            this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
              console.log("🚀 ~ file: nftsell.component.ts ~ line 137 ~ NftsellComponent ~ this.authService.ConnectProviderWallet ~ success", success)
              this.tokenAddress = success

              this.nftService.prepareOrderHash().then(async (succ: any) => {
                console.log("🚀 ~ file: nftsell.component.ts ~ line 60 ~ NftsellComponent ~ this.accountsService.exchange ~ succ", succ)


                // 1.sellSign(hash) => hash from prepareOrderHash

                let sig1 = await window.web3.eth.personal.sign(succ, this.authService.walletAddress, '');

                let r = sig1.slice(0, 66);
                let s = '0x' + sig1.slice(66, 130);
                let v = '0x' + sig1.slice(130, 132);

                let signVRS = { v: v, r: r, s: s, message: succ };
                localStorage.setItem('sellervrs', JSON.stringify(signVRS))
                console.log("🚀 ~ file: nftsell.component.ts ~ line 130 ~ NftsellComponent ~ this.nftService.prepareOrderHash ~ signVRS", signVRS)

                this.isValidsellNftForm = false

                this.nftService.setApprovalForAll('0x83b747630a14ab61863a0746799e5faaed934535', true).subscribe((setApprovalForAll: any) => {
                  if (setApprovalForAll.status == true) {
                    this.snackbarService.add({
                      msg: ' <strong> Successfully Listed for sale </strong> ',
                      timeout: 3000,
                      action: {
                        text: 'Close'
                      }
                    })
                  }

                  console.log(setApprovalForAll);

                  if (setApprovalForAll.status == false) {
                    this.snackbarService.add({
                      msg: ' <strong> User Rejected </strong> ',
                      timeout: 2000,
                      action: {
                        text: 'Close'
                      }
                    })
                  }
                })
              })
            })
          })
        })
    }
    else {
      this.snackbarService.add({
        msg: ' <strong> Please Make Subscription </strong> ',
        timeout: 3000,
        action: {
          text: 'Go',
          onClick: (snack) => {

            this.router.navigate([`/`]);

          },
        }
      })
    }

  }


  sellBidNft() {


    if (this.checkSubscription.email != null) {

      this.isValidsellNftForm = true

      if (this.sellNftForm.valid)

        this.basicService.getTokenAbi().subscribe((success) => {
          console.log("🚀 ~ file: nftsell.component.ts ~ line 127 ~ NftsellComponent ~ this.basicService.getTokenAbi ~ success", success)

          this.authService.ConnectWallet('metamask').subscribe((success) => {
            console.log("🚀 ~ file: nftsell.component.ts ~ line 132 ~ NftsellComponent ~ this.authService.ConnectWallet ~ success", success)

            this.authService.ConnectProviderWallet('metamask').subscribe(async (success) => {
              console.log("🚀 ~ file: nftsell.component.ts ~ line 137 ~ NftsellComponent ~ this.authService.ConnectProviderWallet ~ success", success)
              this.tokenAddress = success

              this.isValidsellNftForm = false

              this.nftService.setApprovalForAll('0x83b747630a14ab61863a0746799e5faaed934535', true).subscribe((succ: any) => {
                console.log(succ);

                if (succ.status == false) {
                  this.snackbarService.add({
                    msg: ' <strong> User Rejected </strong> ',
                    timeout: 2000,
                    action: {
                      text: 'Close'
                    }
                  })
                }

                console.log(succ);


                if (succ.status == true) {
                  this.snackbarService.add({
                    msg: ' <strong> Successfully Listed for Bid </strong> ',
                    timeout: 3000,
                    action: {
                      text: 'Close'
                    }
                  })
                }
              })
            })
          })
        })
    }
    else {
      this.snackbarService.add({
        msg: ' <strong> Please Make Subscription </strong> ',
        timeout: 3000,
        action: {
          text: 'Go',
          onClick: (snack) => {

            this.router.navigate([`/`]);

          },
        }
      })
    }

  }

  updateSellnft() {

    // Get back item "sellNFT" from local storage
    var sellNft = JSON.parse(localStorage.getItem("createNFT"))

    const update = this.sellNFT.find((item: { id: any; }) => item.id === this.id)
    const updateSetPrice = update['setPrice'] = this.setPrice
    console.log(updateSetPrice)

    // Get localstorage index
    let index = sellNft.findIndex((item: { id: any; }) => item.id === this.id);

    // Change value
    sellNft[index].setPrice = updateSetPrice

    // Save new item with updated value
    localStorage.setItem("createNFT", JSON.stringify(sellNft))

    this.sellNft()
  }


  updateBidSellnft() {

    // Get back item "sellNFT" from local storage
    var sellNft = JSON.parse(localStorage.getItem("createNFT"))

    const update = this.sellNFT.find((item: { id: any; }) => item.id === this.id)
    const updateAuctionPrice = update['auctionPrice'] = this.sellNftForm.value.auctionPrice
    const updateDate = update['date'] = this.sellNftForm.value.date
    console.log(updateAuctionPrice)
    console.log(updateDate)

    // Get localstorage index
    let index = sellNft.findIndex((item: { id: any; }) => item.id === this.id);

    // Change value
    sellNft[index].auctionPrice = updateAuctionPrice
    sellNft[index].date = updateDate

    // Save new item with updated value
    localStorage.setItem("createNFT", JSON.stringify(sellNft))

    this.sellBidNft()
  }


}
