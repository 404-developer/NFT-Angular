import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { AppComponent } from './app.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { DomainDetailsComponent } from './domain-details/domain-details.component';
import { BlogComponent } from './blog/blog.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { FaqComponent } from './faq/faq.component';
import { HomeComponent } from './home/home.component';
import { ArtComponent } from './art/art.component';
import { AboutComponent } from './about/about.component';
import { ExploreComponent } from './explore/explore.component';
import { AllnftComponent } from './allnft/allnft.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CreateComponent } from './create/create.component';
import { AccordionModule }  from 'ngx-bootstrap/accordion';
import { DomainnamesComponent } from './domainnames/domainnames.component';
import { ExploreDetailsComponent } from './explore-details/explore-details.component';
import { MusicComponent } from './music/music.component';
import { NftsellComponent } from './nftsell/nftsell.component';
import { NftbuyComponent } from './nftbuy/nftbuy.component';
import { NewComponent } from './new/new.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SnackbarModule, SnackbarService } from 'ngx-snackbar';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FaqComponent,
    HomeComponent,
    ExploreComponent,
    AboutComponent,
    AllnftComponent,
    ArtComponent,
    BlogComponent,
    BlogDetailsComponent,
    CreateComponent,
    DomainDetailsComponent,
    DomainnamesComponent,
    ExploreDetailsComponent,
    MusicComponent,
    NftsellComponent,
    NftbuyComponent,
    NewComponent,
    MyprofileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ModalModule.forRoot(),
    BsDropdownModule.forRoot() ,
    AccordionModule.forRoot(),
    TabsModule.forRoot(),
    ProgressbarModule.forRoot(),
    SnackbarModule.forRoot(),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
