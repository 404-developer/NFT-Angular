import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BasicService {
  TokenABI: any;
  RouterABI: any;
  ExchangeABI: any;
  WethABI:any
  NftMarketABI:any;

  ContractDetails = {
    WBNBAddress: '',
    RouterContract: '0x37806dd08A6C15449b7a4118F15cdC38551750dA',
    ExchangeContract: '0x83B747630A14AB61863A0746799e5FaaED934535',
    WethContract: '0x08615d29CbE0039EAc28427C4029bf61Fe3e03a5',
    NftMarketContract: '0xb6Be3A23d21C7ba0723cDBCB478351033e14896A'
  };

  
  constructor(private httpClient: HttpClient) {}

  public getTokenAbi() {
    return new Observable((subscriber) => {
      this.httpClient.get('assets/json/abi.json').subscribe((suc: any) => {
        this.TokenABI = suc.TokenABI;       
        this.RouterABI = suc.RouterABI; 
        this.ExchangeABI = suc.ExchangeABI;
        this.WethABI = suc.WethABI
        this.NftMarketABI = suc.NftMarketABI
        subscriber.next(true);
       
      });
    });
  }

  stopSubscribe(subscriber: any) {
    if (subscriber) {
      subscriber.unsubscribe();
    }
  }
}