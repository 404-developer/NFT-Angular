import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'risu-nft';


  constructor(
   
    private router: Router
  ) {
    // this.getSettings();  

    this.router.events.subscribe((evt: any) => {

      let route: any = evt;

      if (route.navigationTrigger == "imperative") {
        window.scrollTo(0, 0);
      }

      if (!(evt instanceof NavigationEnd)) {
        return;
      }

    });
  }

}
