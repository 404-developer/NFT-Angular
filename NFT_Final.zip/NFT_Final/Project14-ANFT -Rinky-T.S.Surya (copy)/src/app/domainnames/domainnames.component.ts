import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domainnames',
  templateUrl: './domainnames.component.html',
  styleUrls: ['./domainnames.component.css']
})
export class DomainnamesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
